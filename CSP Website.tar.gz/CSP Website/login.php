<?php
$host = "localhost";
$dbname ="artgallery";
$username = "andyhanson";
$password = "WaterSkiing";
?>
