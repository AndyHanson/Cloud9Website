<?php
//process.php
if ($_SERVER["REQUEST_METHOD"] == "POST")
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "andyhanson";
    $mysql_password = "WaterSkiing";
    $mysql_database = "movies";
    
    $MovieName = $_POST["MovieNamev2"];
	$WhoMadeIt = $_POST["WhoMadeIt"];
	$Year = $_POST["Year"];
	
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	    $statement = $mysqli->prepare("DELETE FROM MovieEntries WHERE MovieName = '" . $MovieName . "'"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		//$statement->bind_param('s', $MovieName); //bind value
		if($statement->execute())
		    {
				//print output text
				echo nl2br($MovieName ." "."has been deleted from the table");
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>