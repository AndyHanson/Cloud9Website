<?php
//process.php
if ($_SERVER["REQUEST_METHOD"] == "POST")
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "andyhanson";
    $mysql_password = "WaterSkiing";
    $mysql_database = "movies";
    
    $MovieNameToChange = $_POST["MovieNameToChange"];
    $NewMovieName = $_POST["NewMovieName"];
	$NewWhoMadeIt = $_POST["NewWhoMadeIt"];
	$NewYear = $_POST["NewYear"];
	
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	    $statement = $mysqli->prepare("UPDATE MovieEntries SET MovieName='" . $NewMovieName . "', WhoMadeIt='" . $NewWhoMadeIt . "', Year='" . $NewYear . "' WHERE MovieName = '" . $MovieNameToChange . "'"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		//$statement->bind_param('s', $MovieName); //bind value
		if($statement->execute())
		    {
				//print output text
				echo nl2br($MovieNameToChange ." has been updated");
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>