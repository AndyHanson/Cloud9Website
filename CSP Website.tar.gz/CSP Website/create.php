<?php
//process.php
if ($_SERVER["REQUEST_METHOD"] == "POST")
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "andyhanson";
    $mysql_password = "WaterSkiing";
    $mysql_database = "movies";
    
    $MovieName = $_POST["MovieName"];
	$WhoMadeIt = $_POST["WhoMadeIt"];
	$Year = $_POST["Year"];
	
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	    // Removed "(MovieName, WhoMadeIt, Year)" from the INSERT statement.  All that is needed is the VALUES part.
	    $statement = $mysqli->prepare("INSERT INTO MovieEntries VALUES(?, ?, ?)"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		//markers are the "?" in the VALUES statement from the prepare statement.  bind_param substitutes the variables for the "?"
		$statement->bind_param('sss',$MovieName, $WhoMadeIt, $Year); //bind value
		if($statement->execute())
		    {
				//print output text
				echo nl2br($MovieName ." "."has been added to the table");
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>
