<?php
//update_delete.php
if ($_GET['action'] == 'Yes') {
    header('location: Update.html');
    exit;
} else if ($_GET['action'] == 'No') {
    //action for No
    header('Location: Main.html');
    exit;
} else {
    header('Location: Main.html');
    exit;
}

?>